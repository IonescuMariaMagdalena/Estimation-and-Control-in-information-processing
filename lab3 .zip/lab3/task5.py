import numpy as np
import matplotlib.pyplot as plt

# Gaussian random variable (mean=0, std=1)
gauss = np.random.normal(0, 1, 1000)

# Uniform random variable (0,1)
uniform = np.random.uniform(0, 1, 1000)

# Histogram Gaussian
plt.figure()
plt.hist(gauss, bins=20)
plt.title("Gaussian Distribution N(0,1)")
plt.xlabel("Value")
plt.ylabel("Frequency")
plt.show()

# Histogram Uniform
plt.figure()
plt.hist(uniform, bins=20)
plt.title("Uniform Distribution U(0,1)")
plt.xlabel("Value")
plt.ylabel("Frequency")
plt.show()

'''
The Gaussian distribution produces a bell-shaped histogram.

Properties:

symmetric around 0
most values near mean
fewer values far from mean

This shape appears because values close to the mean have higher probability.

The uniform distribution produces a flat histogram.

Properties:

all values equally likely
constant probability
rectangular shape

Property	Gaussian	Uniform
Shape	Bell-shaped	Flat
Mean	0	0.5
Spread	around mean	equal everywhere
Probability	higher near mean	same everywhere

Gaussian distribution has concentration around the mean,
while uniform distribution has equal probability for all values.

This shows that different random variables produce different histogram shapes depending on their probability distribution.
'''

