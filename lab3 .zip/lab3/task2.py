import numpy as np
import matplotlib.pyplot as plt

# Step 1: simulate X ~ Uniform(0,1)
X = np.random.uniform(0, 1, 1000)

# Step 2: plot histogram
plt.figure()
plt.hist(X, bins=20)

plt.title("Histogram of X ~ Uniform(0,1)")
plt.xlabel("Value")
plt.ylabel("Frequency") 

plt.show()

'''
The histogram has a rectangular (flat) shape, which is characteristic of the uniform distribution.

In a Uniform(0,1) distribution:

All values between 0 and 1 have the same probability

The probability density is constant

No value is more likely than another

Because of this, the histogram bars have approximately the same height across the interval.

Small variations appear due to randomness, but overall the shape remains flat.

As the number of samples increases, the histogram becomes more uniform and closer to the theoretical distribution.

This confirms that the simulated variable follows a Uniform(0,1) distribution.
'''