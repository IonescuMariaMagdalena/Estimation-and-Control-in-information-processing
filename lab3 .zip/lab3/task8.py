import numpy as np

# True value
x = 10

# Generate Gaussian noise
noise = np.random.normal(0, 1, 1000)

# Noisy measurements
y = x + noise

# Estimate average
x_est = np.mean(y)

# Estimation error
error = x_est - x

print("True value =", x)
print("Estimated average =", x_est)
print("Estimation error =", error)