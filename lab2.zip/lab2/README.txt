This laboratory was made by
Dumitru Teodora Iulia 1242A
Ionescu Maria Magdalena 1242A
Sirbu Constantin Radu 1242A