import numpy as np
import matplotlib.pyplot as plt

# True value
x = 10

# Generate Gaussian noise (mean 0, std 1)
noise = np.random.normal(0, 1, 1000)

# Measurements
y = x + noise

# Plot histogram of measurements
plt.figure()
plt.hist(y, bins=20)

plt.title("Measurement distribution (y = x + noise)")
plt.xlabel("Value")
plt.ylabel("Frequency")

plt.show()