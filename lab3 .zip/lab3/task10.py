import numpy as np

# Number of simulations
N = 1000

# Simulate two events
# Event B happens with probability 0.6
B = np.random.rand(N) < 0.6

# Event A depends on B
# If B happens, A has higher probability
A = np.zeros(N, dtype=bool)

for i in range(N):
    if B[i]:
        A[i] = np.random.rand() < 0.8
    else:
        A[i] = np.random.rand() < 0.3

# Estimate conditional probability P(A|B)
P_A_given_B = np.sum(A & B) / np.sum(B)

print("Estimated P(A|B) =", P_A_given_B)